#include <windows.h>
BOOL s_fgets(HANDLE hFile, char *buffer, DWORD n);
