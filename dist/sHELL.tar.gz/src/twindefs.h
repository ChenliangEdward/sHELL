#include "minwindef.h"
#include <windows.h>

typedef WINAPI FARPROC _GetProcAddress(HMODULE hModule, LPCSTR szFuncName);
