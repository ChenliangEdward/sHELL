// opcodes
//
#define OPCODE_clear 255552908
#define OPCODE_echo 2090214596
#define OPCODE_ls 5863588
#define OPCODE_cat 193488125
#define OPCODE_exec 2090237354
#define OPCODE_http 2090341317
#define OPCODE_b64 193485553
#define OPCODE_hex 193493706
#define OPCODE_exit 2090237503
#define OPCODE_help 2090324718
